package com.example.switchapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView first, second;
    String textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editText = findViewById(R.id.editText);
        Button button = findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
               first = (TextView) findViewById(R.id.editText2);
               second = (TextView) findViewById(R.id.editText3);
                String num;
                    if(editText.getText() != null) {
                        num = editText.getText().toString();

                        switch (num){

                           case "1":

                                showToast(" January"  +" "+ first.getText()+", "+ second.getText());

                            case "2":
                                showToast("Febuary"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "3":
                                showToast("March"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "4":
                                showToast("April"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "5":
                                showToast("May"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "6":
                                showToast("June"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "7":
                                showToast("July"  +" "+ first.getText()+", "+ second.getText());
                           case "8":
                            showToast("August"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "9":
                            showToast("September"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "10":
                            showToast("October"  +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "11":
                            showToast("November" +" "+ first.getText()+", "+ second.getText());
                                break;
                            case "12":
                                showToast("December" +" "+ first.getText()+", "+ second.getText());
                                break;
                            default:
                                showToast("---INVALID---");
                                break;
                        }
                    }

                }
            });

        }

        void showToast(String msg){
            Toast.makeText(MainActivity.this,"Your Birthday is " + msg,Toast.LENGTH_LONG).show();
        }
    }